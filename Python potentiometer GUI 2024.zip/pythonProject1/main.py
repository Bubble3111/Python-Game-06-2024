from tkinter import ttk
import tkinter.ttk
from tkinter import *
import serial
from time import sleep
from PIL import ImageTk, Image

port = serial.Serial('COM3', baudrate=115200, timeout=0)

preValue = 100


def getValue():
    global preValue
    value = port.read(7)
    if 7 > len(value) > 0:
        value = str(value).replace("'", '')
        value = value.replace('b', '')
        if int(value) > 2300:
            value = "2300"
        preValue = value
        print(value)
        if int(value) < 20 and int(preValue) > 100:
            return preValue
        return value
    else:
        return preValue


isSegmentDisplayWindow = False


def segmentDisplay():
    global isSegmentDisplayWindow
    isSegmentDisplayWindow = not isSegmentDisplayWindow


def openExtendedWindowButtonText():
    if isSegmentDisplayWindow:
        return "Close Extended Window"
    else:
        return "Open Extended Window"


def rgb2hex(r, g, b):
    return "#{:02x}{:02x}{:02x}".format(r, g, b)


test = Tk()
test.resizable(False, False)
test.config(bg='#353a52')
test.geometry("400x600")
test.title("Potentiometer Value")
test.iconbitmap('images/burger_hamburger_icon_263225.ico')

normalWindow = Frame()
normalWindow.config(height=600, width=400, background='#353a52')
normalWindow.place(x=0, y=0)

extendedWindow = Frame()
extendedWindow.config(background='#353a52', height=606, width=403, highlightbackground='gray', highlightthickness=3)
extendedWindow.place(x=400, y=-3)

openExtendedWindow = Button(normalWindow, foreground='white', activebackground='#abacff', activeforeground='#000282',
                            width=25, text=openExtendedWindowButtonText(), highlightbackground='blue',
                            background='#4f5469', command=segmentDisplay)
openExtendedWindow.place(x=200, y=530)

closeWindowButton = Button(normalWindow, width=25, text='Close Window', command=test.destroy, foreground='red',
                           activebackground='#fa5a5a', activeforeground='#bd0000', background='#4f5469')
closeWindowButton.place(x=200, y=560)

showSegmentDisplayValue = Label(extendedWindow, foreground='white', background='#353a52')
showSegmentDisplayValue.place(x=20, y=50)

percentageOfMaxValue = Label(extendedWindow, foreground='white', background='#353a52')
percentageOfMaxValue.place(x=20, y=85)

openImage = Image.open("images/neutralNeedle.png").resize((310, 330))
openGauge = Image.open('images/gauge colored.png').convert('RGBA')
needleTk = ImageTk.PhotoImage(openImage)
needle = Label(normalWindow, image=needleTk, borderwidth=0, highlightthickness=0)
needle.place(x=40, y=130)

progressBar = tkinter.ttk.Progressbar(length=300)
progressBar.place(x=45, y=330)

showValue = Label(normalWindow, text=str(getValue()), width='30', foreground='white', background='#353a52')
showValue.place(x=95, y=370)

ledRepresentationText = Label(extendedWindow, text='Representation of the LED', foreground='white',
                              background='#353a52')
ledRepresentationText.place(x=20, y=120)
ledRepresentation = Frame(extendedWindow, height='25', width='25',
                          background=(rgb2hex(255 * int(getValue()) // 2310, 106 * int(getValue()) // 2310, 0)))
ledRepresentation.place(x=168, y=116)
while True:
    ledRepresentation.config(background=rgb2hex(255 * int(getValue()) // 2310, 106 * int(getValue()) // 2310, 0))
    progressBar.destroy()
    progressBar = tkinter.ttk.Progressbar(length=300)
    progressBar.place(x=45, y=330)
    progressBar.step((100 * int(getValue()) // 2300))
    rotatingNeedle = openImage.rotate(-180 * int(getValue()) // 2280).convert('RGBA')
    needleAndGauge = Image.alpha_composite(openGauge, rotatingNeedle)
    needleTk = ImageTk.PhotoImage(needleAndGauge)
    needle.configure(image=needleTk)
    showValue.config(text='Value from potentiometer:  ' + str(getValue()))

    showSegmentDisplayValue.config(text='Value displayed on the 7 segments display:  ' + str(int(getValue()) // 233))
    percentageOfMaxValue.config(text='Percentage of max value:  ' + str(100 * int(getValue()) // 2280) + '%')

    openExtendedWindow.config(text=openExtendedWindowButtonText())

    if isSegmentDisplayWindow:
        test.geometry("800x600")
    else:
        test.geometry('400x600')

    sleep(0.1)
    test.update()
