from tkinter import *
from time import sleep
from PIL import ImageTk, Image

isSegmentDisplayWindow = False
def segmentDisplay():
    global isSegmentDisplayWindow
    isSegmentDisplayWindow = not isSegmentDisplayWindow

def openExtendedWindowButtonText():
    if isSegmentDisplayWindow:
        return "Close Extended Window"
    else:
        return "Open Extended Window"





test = Tk()
test.resizable(False, False)
test.geometry("400x600")
test.title("Potentiometer Value")
test.iconbitmap('images/burger_hamburger_icon_263225.ico')

normalWindow = Frame()
normalWindow.config(height=600, width=400)
normalWindow.place(x=0, y=0)

extendedWindow = Frame()
extendedWindow.config(height=606, width=403, highlightbackground='gray', highlightthickness=3)
extendedWindow.place(x=400, y=-3)

openExtendedWindow = Button(normalWindow, activebackground='gray', width=25, text=openExtendedWindowButtonText(), command=segmentDisplay)
openExtendedWindow.place(x=200, y=530)

closeWindowButton = Button(normalWindow, width=25, text = 'Close Window', command=test.destroy)
closeWindowButton.place(x=200, y=560)

showSegmentDisplayValue = Label(extendedWindow, highlightbackground='gray', highlightthickness=1)
showSegmentDisplayValue.place(x=20, y=50)

percentageOfMaxValue = Label(extendedWindow, highlightbackground='gray', highlightthickness=1)
percentageOfMaxValue.place(x=20, y=85)

rawEntryFromSTM32 = Label(extendedWindow, highlightbackground='gray', highlightthickness=1)
rawEntryFromSTM32.place(x=20, y=120)

openImage = Image.open("images/neutralNeedle.png").resize((310, 330))
openGauge = Image.open('images/gauge colored.png').convert('RGBA')
needleTk = ImageTk.PhotoImage(openImage)
needle = Label(normalWindow, image=needleTk)
needle.place(x=40, y=130)

showValue = Label(normalWindow, width='30', highlightbackground='gray', highlightthickness=1)
showValue.place(x=95, y=360)
a = 1
while True:
    a += 10
    b = a % 2300
    rotatingNeedle = openImage.rotate(-180*int(b)//2280).convert('RGBA')
    needleAndGauge = Image.alpha_composite(openGauge, rotatingNeedle)
    needleTk = ImageTk.PhotoImage(needleAndGauge)
    needle.configure(image=needleTk)
    showValue.config(text='Value from potentiometer:  '+str(b))

    showSegmentDisplayValue.config(text='Value displayed on the 7 segments display:  '+str(int(b)//233))
    percentageOfMaxValue.config(text='Percentage of max value:  ' + str(100*int(b)//2280)+'%')
    rawEntryFromSTM32.config(text='Raw entry from Nucleo card: '+str(b))


    openExtendedWindow.config(text=openExtendedWindowButtonText())

    if isSegmentDisplayWindow:
        test.geometry("800x600")
    else:
        test.geometry('400x600')

    sleep(0.1)
    test.update()
